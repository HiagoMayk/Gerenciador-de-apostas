
public interface IDAOObjetoAposta 
{
	public void addObjetoAposta();
	public void removerObjetoAposta();
	public void procurarObjetoAposta(ObjetoAposta objAposta);
	public void getObjetoApostas();
}

