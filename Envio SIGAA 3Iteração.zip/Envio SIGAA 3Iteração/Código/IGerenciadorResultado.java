
public interface IGerenciadorResultado 
{
	public void obterResultado();
}
