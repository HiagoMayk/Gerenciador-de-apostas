
//Esta classe contém os valores ganhos por classificação
public class Premio
{
	private float premio;
	
	public Premio(float premio) 
	{
		this.premio = premio;
	}

	public float getPremio() 
	{
		return premio;
	}

	public void setPremio(float premio) 
	{
		this.premio = premio;
	}
}