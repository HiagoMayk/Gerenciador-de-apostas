
FRAMEWORK: Gerenciador de Apostas

EXCECUÇÃO:
Para executar o a instancia do framework deve-se apenas abri-lo em uma IDE (ex:Eclipse) e executar.
Caso se queira variar os dados de entrada é só modifica-los na classe EntradaSaida que, neste momento, é onde
estamos obtendo os dados para a funcionalidade a instancia.

PADRÕES UTILIZADOS:
Atualmente estamos usando o padrão DAO para acesso aos dados e o padrão Template Methodo na classe RegraJogo,
mais especificamente no método apricarRegraJogo.
pois 
